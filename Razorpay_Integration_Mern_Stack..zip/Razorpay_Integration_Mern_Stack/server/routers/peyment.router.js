import express from "express";
import { checkout, peymentVerification } from "../controllers/payment.controller.js";

const router = express.Router();

router.route("/checkout").post(checkout);
router.route("/paymentverification").post(peymentVerification)
export  default router;