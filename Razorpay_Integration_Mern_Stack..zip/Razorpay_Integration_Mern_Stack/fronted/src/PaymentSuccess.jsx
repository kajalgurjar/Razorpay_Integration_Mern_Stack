import { Box, Center, Heading, VStack } from '@chakra-ui/react'
import React from 'react'
import {useSearchParams} from "react-router-dom"

const PaymentSuccess = () => {

  const seachQuery = useSearchParams()[0]
     console.log(seachQuery.get("reference"))
  return (
   <Box>
    <VStack h="100vh" justifyContent={Center}>

      <Heading textTransform={"uppercase"}></Heading>

      <text>
      reference No.3423423434
      </text>
    </VStack>
   </Box>
  )
}

export default PaymentSuccess